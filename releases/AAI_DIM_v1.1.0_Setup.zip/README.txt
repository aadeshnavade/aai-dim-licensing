AAI DIM Autonomous Dimensioning & AI Copilot for Revit
Version: 1.1.0
Multi-version installer for Revit 2024 through Revit 2027+
