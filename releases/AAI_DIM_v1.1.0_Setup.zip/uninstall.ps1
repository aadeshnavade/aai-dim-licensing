# AAI DIM - Uninstaller Script
$ErrorActionPreference = "SilentlyContinue"

$revitAddinsRoot = "$env:APPDATA\Autodesk\Revit\Addins"
$versions = @("2026", "2025", "2024", "2027")

Write-Output "==> Uninstalling AAI DIM from Autodesk Revit..."

foreach ($ver in $versions) {
    $manifest = "$revitAddinsRoot\$ver\AaiDim.addin"
    $targetDir = "$revitAddinsRoot\$ver\AaiDim"

    if (Test-Path $manifest) {
        Remove-Item -Path $manifest -Force
        Write-Output "Removed manifest: $manifest"
    }
    if (Test-Path $targetDir) {
        Remove-Item -Path $targetDir -Recurse -Force
        Write-Output "Removed files: $targetDir"
    }
}

Write-Output "AAI DIM has been completely removed."
