# AAI DIM - Installation Script for Autodesk Revit
$ErrorActionPreference = "Stop"

$clientId = "D74F1A82-62C3-49F1-A81E-41952B976DA2"
$vendorId = "AAIDIM"

Write-Output '=========================================================='
Write-Output '   AAI DIM — AI-Powered Architectural Dimensioning'
Write-Output '   Developer: Aadesh Navade (+91 9341102949)'
Write-Output '=========================================================='
Write-Output ''

# Detect installed Revit version addin folders
$revitAddinsRoot = "$env:APPDATA\Autodesk\Revit\Addins"
$installedVersions = @('2026', '2025', '2024', '2027')

$buildOutput = "$PSScriptRoot\bin\Release\net8.0-windows"
if (!(Test-Path "$buildOutput\AaiDim.dll")) {
    $buildOutput = $PSScriptRoot
}

if (!(Test-Path "$buildOutput\AaiDim.dll")) {
    Write-Output "Building project in Release mode first..."
    & "$env:USERPROFILE\.dotnet\dotnet.exe" build -c Release "$PSScriptRoot\AaiDim.csproj"
    $buildOutput = "$PSScriptRoot\bin\Release\net8.0-windows"
}

$installedAny = $false

foreach ($ver in $installedVersions) {
    $addinDir = "$revitAddinsRoot\$ver"
    $targetDir = "$addinDir\AaiDim"
    $manifestPath = "$addinDir\AaiDim.addin"

    # Check if this Revit version folder exists or default to 2026
    $folderExists = Test-Path $addinDir

    if ($folderExists -or $ver -eq '2026') {
        Write-Output "==> Installing AAI DIM for Autodesk Revit $ver..."

        if (!(Test-Path $addinDir)) {
            New-Item -ItemType Directory -Path $addinDir -Force | Out-Null
        }
        if (!(Test-Path $targetDir)) {
            New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        }

        Copy-Item -Path "$buildOutput\AaiDim.dll" -Destination "$targetDir\AaiDim.dll" -Force
        Copy-Item -Path "$buildOutput\AaiDim.pdb" -Destination "$targetDir\AaiDim.pdb" -Force -ErrorAction SilentlyContinue

        Get-ChildItem -Path $buildOutput -Filter "*.dll" | ForEach-Object {
            if ($_.Name -ne "RevitAPI.dll" -and $_.Name -ne "RevitAPIUI.dll") {
                Copy-Item -Path $_.FullName -Destination "$targetDir\$($_.Name)" -Force
            }
        }

        $manifestContent = @"
<?xml version="1.0" encoding="utf-8"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>AAI DIM</Name>
    <Assembly>$targetDir\AaiDim.dll</Assembly>
    <FullClassName>AaiDim.App</FullClassName>
    <ClientId>$clientId</ClientId>
    <VendorId>$vendorId</VendorId>
    <VendorDescription>AAI DIM — AI-Powered Architectural Dimensioning by Aadesh Navade</VendorDescription>
  </AddIn>
</RevitAddIns>
"@

        [System.IO.File]::WriteAllText($manifestPath, $manifestContent, [System.Text.Encoding]::UTF8)

        # Pre-approve in CodeSigning registry to eliminate security warning popup
        $codeSigningKey = "HKCU:\Software\Autodesk\Revit\Autodesk Revit $ver\CodeSigning"
        if (!(Test-Path $codeSigningKey)) {
            New-Item -Path $codeSigningKey -Force -ErrorAction SilentlyContinue | Out-Null
        }
        New-ItemProperty -Path $codeSigningKey -Name $clientId -Value 1 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null

        Write-Output "    Successfully deployed to Revit $ver"
        Write-Output "    Assembly: $targetDir\AaiDim.dll"
        Write-Output "    Manifest: $manifestPath"
        $installedAny = $true
    }
}

if ($installedAny) {
    Write-Output ''
    Write-Output '=========================================================='
    Write-Output ' SUCCESS: AAI DIM has been installed successfully!'
    Write-Output ' Launch Autodesk Revit to use the new AAI DIM ribbon tab'
    Write-Output ' and the interactive AAI Assistant.'
    Write-Output ' For support, contact Aadesh Navade on WhatsApp: +91 9341102949'
    Write-Output '=========================================================='
} else {
    Write-Warning 'Could not find a supported Revit installation on this PC.'
}
